from django.db import models

class signup(models.Model):
	adhaarno=models.CharField(max_length=50,null=True)
	name=models.CharField(max_length=50,null=True)
	localty=models.CharField(max_length=50,null=True)
	dob=models.CharField(max_length=50,null=True)
	number=models.CharField(max_length=50,null=True)
	emailid=models.CharField(max_length=50,null=True)
	city=models.CharField(max_length=50,null=True)
	state=models.CharField(max_length=50,null=True)

class report_user(models.Model):
	adhaarno=models.CharField(max_length=50,null=True)
	lat=models.FloatField(default=0.0,null=True)
	lng=models.FloatField(default=0.0,null=True)
	crime_type=models.CharField(max_length=50,null=True)
	desp=models.CharField(max_length=50,null=True)
	img=models.ImageField(upload_to='report/Images', height_field=None, width_field=None,null=True)
	vid=models.CharField(max_length=50,null=True)
	aud=models.CharField(max_length=50,null=True)
	catgeory=models.CharField(max_length=50,null=True)

class priority(models.Model):
	prid=models.AutoField(primary_key=True)
	crime_type=models.CharField(max_length=100,null=True)
	priorities=models.IntegerField(default=0)

class activemode(models.Model):
	activemode_id=models.AutoField(primary_key=True)
	s_lat=models.FloatField(default=0.0)
	s_lng=models.FloatField(default=0.0)
	d_lat=models.FloatField(default=0.0)
	d_lng=models.FloatField(default=0.0)
	rest_time=models.FloatField(default=0.0)
	time_interval=models.FloatField(default=0.0)
	threshold=models.FloatField(default=0.0)
