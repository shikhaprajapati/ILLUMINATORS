from django.shortcuts import render
from home.models import report_user

# Create your views here

def userhome(request):
	g=report_user.objects.all()
	return render(request,'userhome.html',{'g':g})

def saferide(request):
	return render(request,'saferide.html')

def safearea(request):
	return render(request,'safearea.html')

def activemode(request):
	return render(request,'activemode.html')

def report(request):
	return render(request,'report.html')

def entries(request):
	return render(request,'entries.html')

def notify(request):
	return render(request,'notify.html')

def deskmain(request):
	g=report_user.objects.all()
	return render(request,'deskmain.html',{'g':g})

def sos(request):
	return render(request,'sos.html')

def user2(request):
	return render(request,'user2.html')