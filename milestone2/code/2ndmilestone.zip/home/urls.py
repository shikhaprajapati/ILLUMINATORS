from django.urls import path
from home import views
from home.views import userhome

urlpatterns = [
    path('', views.userhome, name='userhome'),
    path('saferide', views.saferide, name='userhome'),
    path('safearea', views.safearea, name='safearea'),
    path('activemode', views.activemode, name='activemode'),
    path('report', views.report, name='report'),
    path('entries',views.entries,name='entries'),
    path('notify',views.notify,name='notify'),
]