from django.shortcuts import render

# Create your views here

def userhome(request):
	return render(request,'userhome.html')

def saferide(request):
	return render(request,'saferide.html')

def safearea(request):
	return render(request,'safearea.html')

def activemode(request):
	return render(request,'activemode.html')

def report(request):
	return render(request,'report.html')